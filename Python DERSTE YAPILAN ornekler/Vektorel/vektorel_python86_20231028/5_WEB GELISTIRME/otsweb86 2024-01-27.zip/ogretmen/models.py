from django.db import models

# Create your models here.
class Ogretmen(models.Model):
  TC = models.CharField(max_length=11)
  AdiSoyadi = models.CharField(max_length=50)
  Brans = models.CharField(max_length=255)