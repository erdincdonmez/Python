from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.template import loader


def ogretmen(request):

    # return HttpResponse("Şu an anasayfadasınız")
    template = loader.get_template('ogretmen.html')
    return HttpResponse(template.render())


# def ogrenci(request):
#     return HttpResponse("Öğrenci bölümü")
