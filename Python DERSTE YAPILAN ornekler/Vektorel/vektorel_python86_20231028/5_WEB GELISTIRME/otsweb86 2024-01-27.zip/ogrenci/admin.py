from django.contrib import admin
from .models import Ogrenci

admin.site.register(Ogrenci)