from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.template import loader


def ogrenci(request):

    # return HttpResponse("Şu an anasayfadasınız")
    template = loader.get_template('ogrencisayfasi.html')
    return HttpResponse(template.render())


from .models import Ogrenci

def ogrencilist(request):
  liste = Ogrenci.objects.all()
  giden = loader.get_template('ogrencilistesi.html')
  icerik ={
      'ogrencilerliste' : liste,
  }
  return HttpResponse(giden.render(icerik, request))


def ogrenciSearchlist(request):
  liste = Ogrenci.objects.filter(AdiSoyad='Kadir AK').values()

  giden = loader.get_template('aramalistesi.html')
  icerik ={
      'ogrencilerliste' : liste,
  }
  return HttpResponse(giden.render(icerik, request))

def sil(request):
  silinecek = Ogrenci.objects.all()[2]
  silinecek.delete()
  
  ogrencilist(request)

def detay(request, id):
  xxx = Ogrenci.objects.get(id=id)
  template = loader.get_template('detay.html')
  context = {
    'item': xxx,
  }
  return HttpResponse(template.render(context, request))


