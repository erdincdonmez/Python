from django.urls import path
from . import views

urlpatterns = [
    path('ogrenci/', views.ogrenci, name='ogrenci'),
    path('ogrencilistesi/', views.ogrencilist, name='ogrencilist'),
    path('ogrenciaramalistesi/',
         views.ogrenciSearchlist,
         name='ogrenciSearchlist'),
    path('student/', views.ogrenci, name='ogrenci'),
    path('sil/', views.sil, name='sil'),
    path('ogrencilistesi/detay/<int:id>', views.detay, name='detay'),
]
