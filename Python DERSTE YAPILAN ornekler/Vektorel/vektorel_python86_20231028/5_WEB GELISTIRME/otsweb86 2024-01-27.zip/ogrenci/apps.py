from django.contrib import admin
from .models import Ogrenci

class OgrenciAdmin(admin.ModelAdmin):
  list_display = ("TC", "AdiSoyadi",)

admin.site.register(Ogrenci)
