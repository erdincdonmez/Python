from django.apps import AppConfig


class KulupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kulup'
