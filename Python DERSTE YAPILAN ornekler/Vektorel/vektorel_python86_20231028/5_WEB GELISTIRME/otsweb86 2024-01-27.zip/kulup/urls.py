from django.urls import path
from . import views

urlpatterns = [
    path('kulupsayfasi/', views.kulupxx, name='kulup'),
    path('kulupler/', views.kulupxx, name='kulupxx'),
]
