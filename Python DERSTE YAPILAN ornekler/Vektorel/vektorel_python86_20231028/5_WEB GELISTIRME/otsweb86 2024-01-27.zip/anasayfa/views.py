from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.template import loader


def anasayfa(request):

    # return HttpResponse("Şu an anasayfadasınız")
    xxxx = loader.get_template('anasayfa.html')
    return HttpResponse(xxxx.render())

def master(request):

    # return HttpResponse("Şu an anasayfadasınız")
    xxxx = loader.get_template('master.html')
    return HttpResponse(xxxx.render())


# def yonetim(request):
#   template = loader.get_template('ana.html')
#   return HttpResponse(template.render())
