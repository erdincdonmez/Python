from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.
from .models import Ogrenci
from django.shortcuts import redirect
from django.shortcuts import get_object_or_404
from django import forms


def ana(request):
    template = loader.get_template('ana.html')
    return HttpResponse(template.render())


def ogrenciler(aa):

    # if aa.method == 'POST':
    #     form = OgrenciForm(aa.POST)
    #     if form.is_valid():
    #         # Form verileri işleme
    #         form.save()  # Veritabanına kaydetme
    # else:
    #         form = OgrenciForm()

    ogrenciliste = Ogrenci.objects.all()
    ogrenciliste1 = Ogrenci.objects.all().values()
    ogrenciliste2 = Ogrenci.objects.values_list('Adi')
    ogrenciliste3 = Ogrenci.objects.filter(Adi='Ensar').values()
    tmp = loader.get_template('ogrenciler.html')
    bb = {
        'abc': ogrenciliste,
        'liste': ogrenciliste1,
        'liste2': ogrenciliste2,
        'liste3': ogrenciliste3,
        # 'form': form,
    }
    return HttpResponse(tmp.render(bb, aa))


def detay(request, id):
    item = Ogrenci.objects.get(id=id)
    template = loader.get_template('detay.html')
    context = {
        'aktarilan': item,
    }
    return HttpResponse(template.render(context, request))


def sil(request, id):
    item = Ogrenci.objects.get(id=id)
    item.delete()
    return redirect('ogrenciler')  #url name


class OgrenciForm(forms.ModelForm):
    class Meta:
        model = Ogrenci
        fields = ['TC', 'Adi',
                  'Soyadi']  # Kullanmak istediğiniz alanları buraya ekleyin


def ekle(request):
    if request.method == 'POST':
        form = OgrenciForm(request.POST)
        if form.is_valid():
            # Form verileri işleme
            form.save()  # Veritabanına kaydetme
            return redirect('ogrenciler')  #url name

    else:
        form = OgrenciForm()
    return render(request, 'ekle.html', {'form': form})
  
def guncelle(request, id):
  ogrenci = get_object_or_404(Ogrenci, id=id)
  # ogrenci = Ogrenci.objects.get(id=id)
  if request.method == 'POST':
      form = OgrenciForm(request.POST, instance=ogrenci)
      if form.is_valid():
          # Form verileri işleme
          form.save()  # Veritab. kaydetme
          return redirect('ogrenciler') #url name
  else:
      form = OgrenciForm(instance=ogrenci)
  return render(request, 'guncelle.html', {'form': form})