from django.urls import path
from . import views

urlpatterns = [
    path('', views.ana, name='ana'),
    path('ogrenciler/', views.ogrenciler, name='ogrenciler'),
    path('ogrenciler/detay/<int:id>', views.detay, name='detay'),
    path('ogrenciler/sil/<int:id>', views.sil, name='sil'),
    path('ogrenciler/ekle/', views.ekle, name='ekle'),
    path('ogrenciler/guncelle/<int:id>', views.guncelle, name='update'),
]
