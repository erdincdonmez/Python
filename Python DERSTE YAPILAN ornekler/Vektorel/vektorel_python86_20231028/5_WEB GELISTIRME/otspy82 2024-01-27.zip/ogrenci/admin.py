from django.contrib import admin

# Register your models here.
from .models import Ogrenci


class OgrenciAdmin(admin.ModelAdmin):
    list_display = (
        "TC",
        "Adi",
        "Soyadi",
    )


admin.site.register(Ogrenci, OgrenciAdmin)
